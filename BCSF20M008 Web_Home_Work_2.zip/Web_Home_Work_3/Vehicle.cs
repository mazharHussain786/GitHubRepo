namespace MyApp
{
    class Vehicle
    {
        public string? Vtype;
        public string? model;
        public string? license_Plate;
        
    }
}