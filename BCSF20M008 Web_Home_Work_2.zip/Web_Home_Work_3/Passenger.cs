namespace MyApp
{
    class passenger
    {
    public string? Pname;
    public string? PN_Passenger;
    public string? V_Passenger;
    
    }

}